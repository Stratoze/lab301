package com.lottery.checker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckerApplicationTests {

	@Test
	void contextLoads() {
	}

}
